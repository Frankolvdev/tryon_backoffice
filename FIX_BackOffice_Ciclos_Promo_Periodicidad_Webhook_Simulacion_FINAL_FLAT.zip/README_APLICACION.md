# FIX BackOffice — Periodicidad + webhook manual + simulación de ciclos

BASE EXACTA
tryon_backoffice-main - 2026-08-07T180619.711.zip

ÚNICOS CAMBIOS
Caja -> Promociones y tokens gratis -> Ciclos recurrentes.

AL CREAR
Antes:
- Inicio del ciclo
- Fin del ciclo

Ahora:
- Saldo real de este ciclo
- Inicio del ciclo actual
- Periodicidad: semanal / mensual / trimestral / anual
- Monto completo de cada ciclo siguiente
- Flag "Permitir simulaciones de ciclo"

El FIN ya no se captura. Lo calcula Backend.

EJEMPLO MODAL
Saldo actual: USD 19.76
Inicio: 01/08/2026
Periodicidad: Mensual
Próximos ciclos: USD 30

La UI mostrará después:
Ciclo actual: 01/08/2026 -> 01/09/2026

BOTÓN MANUAL
Cada fuente tiene:
"Revisar ciclo ahora"

Ese botón llama al nuevo webhook ADMIN.
Si todavía no vence, no cambia nada.
Si vence, usa el mismo rollover real e idempotente del backend.

SIMULACIÓN
Si "Permitir simulaciones" está apagado:
- no se puede simular.

Si está encendido:
- aparece Fecha que quieres simular;
- aparece "Simular webhook";
- la respuesta es solo una vista previa;
- no cambia dinero ni ciclos reales.

CAMBIAR PERIODICIDAD
Puede cambiarse por fuente.
El ciclo actualmente abierto conserva su fecha.
La nueva periodicidad aplica al siguiente ciclo.

BLINDAJE
No cambia ninguna otra sección de Caja, usuarios, generaciones o Finanzas.
No recalcula fórmulas en frontend.

VALIDACIÓN
Los 2 archivos modificados pasaron TypeScript 5.8.3 transpileModule:
0 errores sintácticos.

GIT
git add .
git commit -m "ux: add promotional cycle periodicity webhook controls"
git push
