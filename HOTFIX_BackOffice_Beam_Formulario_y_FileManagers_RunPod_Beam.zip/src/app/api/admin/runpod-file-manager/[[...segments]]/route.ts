import { NextRequest } from "next/server";
import { proxyAdminRequest } from "@/lib/api/admin-proxy";

type Context = { params: Promise<{ segments?: string[] }> };

function target(request: NextRequest, segments: string[] | undefined) {
  const suffix = segments?.length ? `/${segments.join("/")}` : "";
  return `/api/v1/admin/runpod-file-manager${suffix}${request.nextUrl.search}`;
}

async function handler(request: NextRequest, context: Context) {
  const { segments } = await context.params;
  return proxyAdminRequest(request, target(request, segments));
}

export { handler as GET, handler as POST, handler as PUT, handler as PATCH, handler as DELETE };
