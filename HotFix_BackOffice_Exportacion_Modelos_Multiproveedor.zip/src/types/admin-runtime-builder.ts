export interface RuntimeCustomNode { name: string; repository: string; commit: string | null; enabled: boolean; install_requirements: boolean; }
export interface RuntimePythonDependency { package: string; version: string | null; enabled: boolean; }
export interface RuntimeModelAsset { resolver?: {class_type:string;field:string;folders:string}; name: string; model_type: "checkpoint"|"vae"|"lora"|"controlnet"|"clip"|"upscaler"|"diffusion_model"|"embedding"|"detector"|"sam"|"ipadapter"|"video_model"|"other"; source_url: string | null; target_path: string; sha256: string | null; strategy: "image"|"volume"|"startup-download"; enabled: boolean; }
export interface RuntimeEnvironmentVariable { key: string; value: string | null; secret: boolean; required: boolean; }
export interface RuntimeVolume { name: string; mount_path: string; read_only: boolean; }
export interface RuntimeBuilderConfig {
  id: number; name: string; provider: "modal" | "runpod" | "beam" | "local"; runtime_name: string; runtime_version: string; python_version: string; cuda_version: string;
  pytorch_index_url: string; comfyui_repository: string; comfyui_commit: string | null;
  target_platform: string; registry_image: string; include_comfyui_manager: boolean;
  custom_nodes: RuntimeCustomNode[]; python_dependencies: RuntimePythonDependency[];
  models: RuntimeModelAsset[]; environment_variables: RuntimeEnvironmentVariable[];
  volumes: RuntimeVolume[]; notes: string | null; project_key: string; module_type: string; container_workdir: string; source_comfyui_path: string | null; workflow_filename: string | null; workflow_json: Record<string, unknown> | null; last_index_summary: Record<string, unknown> | null; export_root_directory: string | null; export_directory: string | null; last_export_archive: string | null; last_export_manifest: Record<string, unknown> | null; last_exported_at: string | null; workspace_status: string; is_active: boolean; created_at: string; updated_at: string;
}
export interface RuntimeValidationIssue { level: "error"|"warning"|"info"; field: string; message: string; }
export interface RuntimeValidationResponse { valid: boolean; issues: RuntimeValidationIssue[]; summary: Record<string, string|number|boolean>; }
export interface RuntimeGeneratedFiles { dockerfile: string; entrypoint: string; runtime_manifest: Record<string, unknown>; custom_nodes_lock: Record<string, unknown>; models_manifest: Record<string, unknown>; env_example: string; }

export type RuntimeBuildStatus =
  | "pending"
  | "building"
  | "validating"
  | "succeeded"
  | "failed"
  | "publishing"
  | "published"
  | "active"
  | "cancelled";

export interface RuntimeBuild {
  id: number;
  runtime_config_id: number;
  version: string;
  image_tag: string;
  status: RuntimeBuildStatus;
  phase: string;
  progress: number;
  logs: string;
  error_message: string | null;
  image_id: string | null;
  image_size_bytes: number | null;
  manifest: Record<string, unknown>;
  validation_result: Record<string, unknown>;
  published: boolean;
  active: boolean;
  started_at: string | null;
  finished_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface RuntimeBuildList {
  items: RuntimeBuild[];
  total: number;
}

export interface RuntimeDockerDiagnostic {
  docker_available: boolean;
  docker_version: string | null;
  buildx_available: boolean;
  registry_image: string;
  active_image: string | null;
  message: string;
}

export interface RuntimeImportReport {
  source_type: string; selected_path: string | null; comfyui_path: string | null;
  comfyui_repository: string; comfyui_commit: string | null; python_executable: string | null;
  python_version: string | null; torch_version: string | null; torch_cuda_version: string | null; gpu_name: string | null;
  custom_nodes: Array<RuntimeCustomNode & {source_path?: string}>;
  models: Array<RuntimeModelAsset & {size_bytes: number}>;
  python_dependencies: RuntimePythonDependency[]; environment_variables: RuntimeEnvironmentVariable[]; volumes: RuntimeVolume[];
  warnings: string[]; summary: {custom_nodes:number;models:number;model_size_bytes:number;python_dependencies:number;git_nodes:number};
}
export interface RuntimeWorkflowAnalysis {
  node_count:number; class_types:string[]; custom_node_classes:string[]; referenced_models:string[]; potentially_missing_nodes:string[];
  summary:{nodes:number;unique_classes:number;referenced_models:number};
}

export interface RuntimeWorkflowResolution extends RuntimeImportReport {
  python_candidates: string[];
  workflow: { node_count:number; class_types:string[]; referenced_models:string[] };
  resolved_classes: Array<{class_type:string;provider:'core'|'custom';provider_name:string;confidence:string}>;
  core_classes: string[];
  unresolved_classes: string[];
  missing_models: string[];
  ambiguous_models: string[];
  summary: RuntimeImportReport["summary"] & {
    workflow_nodes:number; unique_classes:number; core_classes:number; resolved_custom_classes:number; runtime_catalog_classes:number; knowledge_base_rules:number; required_custom_nodes:number; required_models:number;
    referenced_models:number; missing_models:number; installed_custom_nodes:number; installed_models:number;
    compatibility_score:number;
  };
}


export interface RuntimeIntelligenceClass {
  class_type:string; python_class:string; display_name:string; provider:string; repository:string|null; commit:string|null;
  source_file:string; relative_file:string; category:string|null; return_types:string[];
  input_fields:Array<{name:string;section:string;model_hint:boolean;spec:string}>; is_loader:boolean;
}
export interface RuntimeIntelligenceProvider {
  provider:string; source_path:string; repository:string|null; commit:string|null; manifests:string[];
  dependencies:Array<{package:string;version:string|null;enabled:boolean;source?:string}>; files_scanned:number; class_count:number; loader_count:number; parse_errors:string[]; classes:RuntimeIntelligenceClass[];
}
export interface RuntimeIntelligenceIndex {
  source_type:string; selected_path:string; comfyui_path:string; custom_node_roots:string[]; providers:RuntimeIntelligenceProvider[];
  classes:RuntimeIntelligenceClass[]; loaders:RuntimeIntelligenceClass[]; duplicate_classes:Record<string,string[]>;
  summary:{custom_node_roots:number;providers:number;repositories:number;classes:number;loaders:number;dependencies:number;parse_errors:number;duplicates:number};
}

export interface RuntimeContextGenerateResponse {
  success: boolean; output_directory: string; archive_path: string; models_copied: number; custom_nodes_copied: number; bytes_copied: number; files_generated: string[]; warnings: string[]; manifest: Record<string, unknown>;
}

export interface RuntimeModelVolumeAnalysis {
  source_comfyui: string; models_detected: number; models_found: number; models_missing: number; bytes_total: number;
  items: Array<RuntimeModelAsset & {found:boolean; source_path:string|null; relative_path:string|null; size_bytes:number}>;
}

export interface RuntimeModelVolumeExportResponse {
  success:boolean; output_directory:string; models_directory:string; manifest_path:string;
  models_detected:number; models_found:number; models_missing:number; models_copied:number; models_skipped:number; bytes_copied:number;
  warnings:string[]; manifest:Record<string, unknown>;
}

export interface RuntimeProject {
  id: number; runtime_config_id: number | null; project_key: string; module_type: string;
  source_comfyui_path: string | null; workflow_filename: string | null; workflow_json: Record<string, unknown> | null;
  container_workdir: string; export_root_directory: string | null; export_directory: string | null;
  last_index_summary: Record<string, unknown> | null; workspace_status: string; last_export_archive: string | null;
  last_export_manifest: Record<string, unknown> | null; last_exported_at: string | null; notes: string | null;
  created_at: string; updated_at: string;
}

export type RuntimeContextJobStatus = "queued" | "running" | "completed" | "failed";

export interface RuntimeContextJob {
  job_id: string;
  status: RuntimeContextJobStatus;
  phase: string;
  progress: number;
  message: string;
  error: string | null;
  result: RuntimeContextGenerateResponse | RuntimeModelVolumeExportResponse | null;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
}

export interface RuntimeModelExportSettings {
  comfyui_path:string; output_directory:string; destination_type:"local"|"docker_volume"|"modal"|"runpod"|"beam";
  docker_volume:string; docker_path:string; calculate_sha256:boolean; overwrite:boolean; skip_identical:boolean;
}
export interface RuntimeLaunchSettings {
  build_name:string; image_name:string; container_name:string; host_port:number; container_port:number;
  models_volume:string; workflows_volume:string; output_volume:string;
  models_mount_path:string; workflows_mount_path:string; output_mount_path:string;
  gpu_mode:"auto"|"nvidia"|"none"; restart_policy:"no"|"always"|"unless-stopped"|"on-failure"; extra_arguments:string[];
}
export interface RuntimeLaunchPreview { command:string; lines:string[] }


export interface RuntimeDeploymentProvider {
  key: string;
  label: string;
  enabled: boolean;
  configured: boolean;
}

export interface RuntimeDeploymentProviderList {
  items: RuntimeDeploymentProvider[];
}

export type RuntimeDeploymentStatus = "queued" | "running" | "deployed" | "failed";

export interface RuntimeDeployment {
  id: string;
  build_id: number;
  provider: string;
  status: RuntimeDeploymentStatus;
  phase: string;
  progress: number;
  message: string;
  logs: string;
  error: string | null;
  app_name: string | null;
  image_tag: string | null;
  volume_name: string | null;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
}

export interface RuntimeBuilderProfileSummary { id:number; name:string; provider:string; runtime_name:string; runtime_version:string; registry_image:string; is_active:boolean; updated_at:string; }
export interface RuntimeBuilderProfileList { items: RuntimeBuilderProfileSummary[]; }
