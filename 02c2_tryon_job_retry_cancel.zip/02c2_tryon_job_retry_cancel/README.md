# 02C2 — Try-On Job Retry / Cancel

Copia `backend/` sobre la raíz del backend y `backoffice/` sobre la raíz del backoffice.

## Backend

Incluye:
- servicio transaccional para reintentar y cancelar jobs Try-On;
- cancelación del job RunPod activo cuando existe;
- validación estricta por estado;
- endpoints administrativos `POST /api/v1/admin/tryon/jobs/{job_id}/retry` y `POST /api/v1/admin/tryon/jobs/{job_id}/cancel`.

### Integración requerida en el router

En `app/api/v1/router.py`, importa e incluye el router:

```python
from app.api.v1.endpoints.admin_tryon_job_actions import router as admin_tryon_job_actions_router
api_router.include_router(admin_tryon_job_actions_router)
```

Si `external_ai_job_repository` aún no tiene `get_latest_by_internal_job`, agrega un método equivalente que filtre por `internal_job_type`, `internal_job_id` y ordene por `created_at DESC`.

## Backoffice

Incluye:
- `TryOnJobActions`, componente cliente con confirmación, loading, errores y refresh;
- tipos de respuesta de acciones.

Inserta el componente en el detalle del job:

```tsx
<TryOnJobActions jobId={job.id} status={job.status} />
```

El proxy dinámico existente `/api/admin/[...segments]` reenviará ambas peticiones al backend.

## Verificación

Backend:

```powershell
python -m compileall app
```

Backoffice:

```powershell
Remove-Item -Recurse -Force .next -ErrorAction SilentlyContinue
npm run build
```
