from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.v1.deps import get_db
from app.api.v1.guards.admin_guard import require_admin
from app.services.tryon_job_action_service import tryon_job_action_service

router = APIRouter(prefix="/admin/tryon/jobs", tags=["Admin Try-On Jobs"])


@router.post("/{job_id}/retry", status_code=status.HTTP_200_OK)
def retry_tryon_job(
    job_id: int,
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    job = tryon_job_action_service.retry(db, job_id=job_id, admin_user_id=getattr(admin, "id", None))
    return {"success": True, "message": "Try-on job queued for retry.", "job_id": job.id, "status": job.status}


@router.post("/{job_id}/cancel", status_code=status.HTTP_200_OK)
def cancel_tryon_job(
    job_id: int,
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    job = tryon_job_action_service.cancel(db, job_id=job_id, admin_user_id=getattr(admin, "id", None))
    return {"success": True, "message": "Try-on job cancelled.", "job_id": job.id, "status": job.status}
