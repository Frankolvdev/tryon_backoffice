from sqlalchemy.orm import Session

from app.common.exceptions import ConflictException, NotFoundException
from app.common.time import utc_now
from app.repositories.external_ai_job_repository import external_ai_job_repository
from app.repositories.runpod_config_repository import runpod_config_repository
from app.repositories.tryon_job_repository import tryon_job_repository
from app.services.external_ai_job_service import external_ai_job_service


class TryOnJobActionService:
    RETRYABLE_STATUSES = {"failed", "cancelled", "canceled", "timed_out", "timeout"}
    CANCELLABLE_STATUSES = {"queued", "pending", "submitted", "running", "processing", "submitting"}

    def _get_job(self, db: Session, job_id: int):
        job = tryon_job_repository.get_by_id(db, job_id)
        if not job:
            raise NotFoundException("Try-on job not found.")
        return job

    def retry(self, db: Session, *, job_id: int, admin_user_id: int | None = None):
        job = self._get_job(db, job_id)
        status = (job.status or "").lower()
        if status not in self.RETRYABLE_STATUSES:
            raise ConflictException(f"Try-on job with status '{job.status}' cannot be retried.")

        # Reset execution fields while preserving source files and original parameters.
        job.status = "queued"
        job.error_message = None
        job.result_file_id = None
        job.started_at = None
        job.finished_at = None
        job.updated_at = utc_now()
        if hasattr(job, "retry_count"):
            job.retry_count = (job.retry_count or 0) + 1
        db.add(job)
        db.commit()
        db.refresh(job)
        return job

    def cancel(self, db: Session, *, job_id: int, admin_user_id: int | None = None):
        job = self._get_job(db, job_id)
        status = (job.status or "").lower()
        if status not in self.CANCELLABLE_STATUSES:
            raise ConflictException(f"Try-on job with status '{job.status}' cannot be cancelled.")

        external_job = external_ai_job_repository.get_latest_by_internal_job(
            db,
            internal_job_type="tryon",
            internal_job_id=job.id,
        )
        if external_job and not external_ai_job_service._is_finished_status(external_job.status or ""):
            config = runpod_config_repository.get_active(db)
            if config and config.endpoint_id:
                external_ai_job_service.cancel_runpod_job(
                    db,
                    external_ai_job_id=external_job.id,
                    endpoint_id=config.endpoint_id,
                )

        job.status = "cancelled"
        job.error_message = "Cancelled by administrator."
        job.finished_at = utc_now()
        job.updated_at = utc_now()
        db.add(job)
        db.commit()
        db.refresh(job)
        return job


tryon_job_action_service = TryOnJobActionService()
