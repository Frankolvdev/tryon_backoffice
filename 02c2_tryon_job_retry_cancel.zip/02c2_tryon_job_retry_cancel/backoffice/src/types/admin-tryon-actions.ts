export type TryOnJobAction = "retry" | "cancel";

export interface TryOnJobActionResponse {
  success: boolean;
  message: string;
  job_id: number;
  status: string;
}
