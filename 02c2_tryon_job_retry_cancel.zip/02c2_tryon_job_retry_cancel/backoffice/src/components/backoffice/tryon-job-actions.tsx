"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { TryOnJobAction, TryOnJobActionResponse } from "@/types/admin-tryon-actions";

type Props = {
  jobId: number;
  status: string;
};

const RETRYABLE = new Set(["failed", "cancelled", "canceled", "timed_out", "timeout"]);
const CANCELLABLE = new Set(["queued", "pending", "submitted", "running", "processing", "submitting"]);

export function TryOnJobActions({ jobId, status }: Props) {
  const router = useRouter();
  const normalizedStatus = status.toLowerCase();
  const [loading, setLoading] = useState<TryOnJobAction | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function execute(action: TryOnJobAction) {
    const label = action === "retry" ? "reintentar" : "cancelar";
    if (!window.confirm(`¿Confirmas que deseas ${label} el job #${jobId}?`)) return;

    setLoading(action);
    setError(null);
    try {
      const response = await fetch(`/api/admin/tryon/jobs/${jobId}/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const payload = (await response.json()) as TryOnJobActionResponse | { detail?: string };
      if (!response.ok) {
        throw new Error("detail" in payload && payload.detail ? payload.detail : `No fue posible ${label} el job.`);
      }
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Ocurrió un error inesperado.");
    } finally {
      setLoading(null);
    }
  }

  const canRetry = RETRYABLE.has(normalizedStatus);
  const canCancel = CANCELLABLE.has(normalizedStatus);

  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          disabled={!canRetry || loading !== null}
          onClick={() => execute("retry")}
          className="rounded-md border border-red-900 bg-red-950/70 px-3 py-2 text-sm font-medium text-red-100 transition hover:bg-red-900 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {loading === "retry" ? "Reintentando…" : "Reintentar job"}
        </button>
        <button
          type="button"
          disabled={!canCancel || loading !== null}
          onClick={() => execute("cancel")}
          className="rounded-md border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm font-medium text-zinc-100 transition hover:bg-zinc-800 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {loading === "cancel" ? "Cancelando…" : "Cancelar job"}
        </button>
      </div>
      {error ? <p className="text-sm text-red-400">{error}</p> : null}
    </div>
  );
}
